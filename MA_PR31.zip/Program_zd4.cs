﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MA_PR_31_zd4
{
    internal class Program
    {
        static readonly string Path2Data = @"input.txt";
        static readonly string Path2Output = @"output.txt";
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines(Path2Data);
            int[] ints = lines[0].Split(' ').Select(int.Parse).ToArray();
            char[] message = lines[1].Split(' ').Select(char.Parse).ToArray();
            char[] text = lines[2].Split(' ').Select(char.Parse).ToArray();
            string output = "GOOD NOTE";
            for (int i = 0; i < message.Length; i++)
            {
                if (text.Contains(message[i])) continue;
                else
                {
                    output = message[i].ToString();
                    break;
                }
            }
            
            Console.WriteLine(output);
            File.WriteAllText(Path2Output,output);
        }
    }
}
