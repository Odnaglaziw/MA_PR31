﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MA_PR31_zd5
{
    internal class Program
    {
        static readonly string Path2Data = @"input.txt";
        static readonly string Path2Output = @"output.txt";
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines(Path2Data); 
            int n = int.Parse(lines[0]);
            string[] part = lines[1].Split(new char[] { ' ' });
            int v = int.Parse(part[0]);
            int t = int.Parse(part[1]);
            string output = (n-(int)(v*t)).ToString();
            File.WriteAllText(Path2Output, output);
        }
    }
}
