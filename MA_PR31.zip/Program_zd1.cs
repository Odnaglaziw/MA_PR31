using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MA_PR31_zd1
{
    internal class Program
    {
        static readonly string Path2Data = @"input.txt";
        static readonly string Path2Output = @"output.txt";
        static void Main(string[] args)
        {
            string[] parts = File.ReadLines(Path2Data).ToArray()[0].Split(' ');
            int k = int.Parse(parts[0]);
            int n = int.Parse(parts[1]);
            int output = n / k;
            File.WriteAllText(Path2Output,output.ToString());
        }
    }
}
